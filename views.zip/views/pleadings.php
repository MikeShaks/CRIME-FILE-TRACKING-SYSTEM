<?php 
$counties= $AUTO_GEN-> counties ;

 

$file_number=$case_desc=null;


$message=$alert=null;
	
if (isset($_POST['case_pleadings'])) {


		 $file_number=@$_POST['file_number'];
		 	$case_desc=@$_POST['desc'];
				
		
				
	
		if($file_number && $case_desc){

			
			
			

				$insertSQL="INSERT into pleadings ( case_no, description ) values(
				
				  ".$Server->quote(explode("{",$file_number)[0]).",
					".$Server->quote($case_desc)."
					
					)";

		
				$insertSQL=$Server->query($insertSQL) or die($Server->error());

				if ($insertSQL) {
					$Server-> commit();
					$alert="<br/>Details have been saved";



						if (@$_GET['action']=="update" && @$_GET['id']) 
			{
				$AUTO_GEN->reload($Site-> site_url);
			}
			else
			{
				
				$AUTO_GEN->reload();


			}

					

				} else {
					$Server->rollback();
					$message.="<br/>Details have not been saved <br/>
						
					";

				}
				
	

			//end server;







	} else {
		$message.=  "<br/>Please provide all the details";
	}
	
	
}



 ?>




<div class="panel panel-primary">
	
<div class="panel-heading"> <h1> Case Pleadings</h1> </div>
	
	<div class="panel-body">

		<?php 

				echo $msg=$message?("<div class='alert alert-danger'> ".$message."</div>"):($alert?"<div class='alert alert-success'> $alert </div>":"");

			 ?>

	<form class="form-horizontal" method="post" action="">
		

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Case Number  <sup class="err fa fa-asterisk "></sup> </label>
				</div>
				<div class="col-sm-8">
				
					<select name="file_number" class="form-control	file_number ">
					<option value="<?php echo $file_number; ?>"><?php echo $file_number; ?></option>
					
					<?php 

						$selectPfno="SELECT * from case_reg_des where  case_no  not in  ( select file_no from file_movement)";
						$selectPfno=$Server->query($selectPfno);

						foreach ($selectPfno as $key ) {
							?>
							<option value="<?php echo $key['case_no']." { ".$key['case_type']." > ".$key['case_sub_type']; ?>"> <?php echo $key['case_no']." { ".$key['case_type']." > ".$key['case_sub_type']; ?></option>

							<?php
						}

					 ?>
					
				</select>


				</div>
			</div>




			

			
<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Case Description <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">


					<div class="panel  panel-default">
						
						<div class="panel-body">
								<textarea class="form-control case_desc"  onkeyup="javascript: checkWords(this.value, 20); " rows="5" name="desc" placeholder="Enter some description." > <?php echo $case_desc; ?> </textarea>
		
						</div>
						<div class="panel-footer showNumberOfWords">
							
						</div>
					</div>

				 		</div>
			</div>

		





			

			


		
				<div class="form-group">
				
				<div class="col-sm-12">
					<button class="btn btn-primary pull-right" name="case_pleadings"> Save</button>
				</div>
			</div>




	</form>
		
		
	</div>
</div>



