<div class="panel panel-primary">
	
<div class="panel-heading"> User Registartion</div>
	
	<div class="panel-body">

		

	<form class="form-horizontal" method="post" action="">
		

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> PF Number </label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="pfno" class="form-control" value="" >
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Full Name <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="name" class="form-control" value="" >
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Gender <sup class="err fa fa-asterisk "></sup> </label>
				</div>
				<div class="col-sm-8">
				<label><input type="radio" name="gender"  value="Male"  > Male </label>
				<label><input type="radio" name="gender"  value="Female"  > Female </label>
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Select Type <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
					
				<select name="type" class="form-control	">
					<option value=""></option>
					<option value="REGISTRAR">REGISTRAR</option>
					<option value="JUDGE">JUDGE</option>
					<option value="OTHERS">OTHERS</option>
				</select>

				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Phone <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="phone" class="form-control" value=""  >
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Email </label>
				</div>
				<div class="col-sm-8">

				<input type="text" name="email" class="form-control" value=""  >
				</div>
			</div>


			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> ID Number </label>
				</div>
				<div class="col-sm-8">

				<input type="text" name="idnumber" class="form-control" value=""  >
				</div>
			</div>

		
				<div class="form-group">
				
				<div class="col-sm-12">
					<button class="btn btn-primary pull-right" name="reg_users"> Save</button>
				</div>
			</div>




	</form>
		
		
	</div>
</div>