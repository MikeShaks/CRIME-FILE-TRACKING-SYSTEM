<?php 



$counties= $AUTO_GEN-> counties ;


$pfno=$AUTO_GEN-> uniqueNumber;

$station=$date_of_arrest=$name=$idnumber=$desc=$police=$category=$gender=$county=$reporter_phone=null;

$referees_phone=null;

$nameT=$genderT=$emailT=$reporter_phoneT=$referees_phoneT=$typeT=$idnumberT=false;

$message=$alert=null;
	
if (isset($_POST['reg_ob'])) {
	
	$station=@$_POST['station'];
	$date_of_arrest=@$_POST['date_of_arrest'];
	$name=@$_POST['name'];
	$idnumber=@$_POST['idnumber'];
	$desc=@$_POST['desc'];

	$referees_phone=@$_POST['referees_phone'];
	$reporter_phone=@$_POST['reporter_phone'];

	$police=@$_POST['police'];

	$category=@$_POST['category'];
	$gender=@$_POST['gender'];
	$county=@$_POST['county'];
	

		if($station && $date_of_arrest && $name  && $desc && $referees_phone && $reporter_phone  && $police && $category && $gender && $county){

			// $new_referees_phone=explode(",", $reporter_phone.",".$referees_phone);

			// $new_referees_phone=array_unique($new_referees_phone);

			// $referees_phone=explode(",",$referees_phone);
		
			
			

			if ($validator->userFullName($station) ) {
				$stationT=true;
			} else {
				$message.="<br/>Please enter a valid Station name";
			}

			if ($validator->userFullName($name) ) {
				$nameT=true;
			} else {
				$message.="<br/>Please enter a valid Suspect's name";
			}


			if ($validator->userFullName($police) ) {
				$policeT=true;
			} else {
				$message.="<br/>Please enter a valid Police name";
			}


			if ($validator->phone($reporter_phone) ) {
				$reporter_phoneT=true;
			} else {
				$message.="<br/>Please enter a valid Reporter's Phone Number";
			}

			if ($validator->phone($referees_phone) ) {
				$referees_phoneT=true;
			} else {
				$message.="<br/>Please enter a valid Referee's Phone Number";
			}


			
			// $mult_phone=$validator -> mult_phone($referees_phone);

			
			// 	if ($mult_phone['true'] ) {
			// 		$referees_phoneT=true;
			// 	} else {
			// 		$message.= "<br/>Please ensure <strong>".$mult_phone['reasons']."</strong> are Valid";
			// 	}



				if ($idnumber) {
					if ($validator->nationalID($idnumber) ) {
				$idnumberT=true;
			} else {
				$message.="<br/>Please enter a valid National ID Number";
			}

			} else {
					$idnumberT=true;
				}
				


			//send to server
			if($idnumberT && $referees_phoneT && $reporter_phoneT && $policeT && $stationT && $nameT){

				$insertSQL="INSERT into ob (p_station, reporting_date , name,id_no, description,reporter_phone , police_name, gender, station_type, county ,referees_phone ) values(
					".$Server->quote($station).",
					".$Server->quote($date_of_arrest).",
					".$Server->quote(strtoupper($name)).",
					".$Server->quote($idnumber).",
					".$Server->quote($desc).",
					
					".$Server->quote($reporter_phone).",
					".$Server->quote($police).",
					".$Server->quote($gender).",
					".$Server->quote($category).",
					".$Server->quote($county).",
					".$Server->quote($referees_phone)."

					)";

			if (@$_GET['action']=="update" && @$_GET['id']) 
			{
				$insertSQL="UPDATE  ob  SET 
				
					date_arrest=".$Server->quote($date_of_arrest).",
					name=".$Server->quote(strtoupper($name)).",
					id_no=".$Server->quote($idnumber).",
					description=".$Server->quote($desc).",
					
					phone".$Server->quote($phone).",
					police_name=".$Server->quote($police).",
					gender=".$Server->quote($gender).",
					station_type=".$Server->quote($category).",
					county=".$Server->quote($county)."

					where 	p_station=".$Server->quote($station);
					

					
			}
				$insertSQL=$Server->query($insertSQL);// or die($Server->error());

				if ($insertSQL) {
					$Server-> commit();
					$alert="<br/>Details have been saved";

						if (@$_GET['action']=="update" && @$_GET['id']) 
			{
				$AUTO_GEN->reload($Site-> site_url);
			}
			else
			{
				//foreach ($new_referees_phone as $phones => $refereesPhoneNumber) {
					
					
					$msg=strtoupper($name)." of ID Number  ".strtoupper($idnumber)." has reported {".ucfirst(strtolower($desc)).". } on ".$date_of_arrest." in ".strtoupper($county)." county at ".strtoupper($station."   ".$category ).". Thank you. ";

				if ($AUTO_GEN-> send_sms($msg,$referees_phone) ) {
					
					$alert.="<br/> A message has been Scheduled to be send to  <strong>".$referees_phone."</strong>";
				} else {
					
					$message.=" An Error Occured during sending process";
				}


				//}

				
				

				$AUTO_GEN->reload();


			}

					

				} else {
					$Server->rollback();
					$message.="<br/>Details have not been saved <br/>
						Please check that there is no duplicate entry of either <strong> ID Number , Email or Phone </strong>
					";

				}
				
	
			}

			//end server;







	} else {
		$message.=  "<br/>Please provide all the details";
	}
	
	
}



 ?>




<div class="panel panel-primary">
	
<div class="panel-heading"> <h1> Occurance Book (OB) Registration</h1> </div>
	
	<div class="panel-body">

		<?php 

				echo $msg=$message?("<div class='alert alert-danger'> ".$message."</div>"):($alert?"<div class='alert alert-success'> $alert </div>":"");

			 ?>

	<form class="form-horizontal" method="post" action="">
		

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Police Station Name  <sup class="err fa fa-asterisk "></sup> </label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="station" class="form-control" value="<?php echo $station; ?>" >
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Select County <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
				
					<select name="county" class="form-control county" onchange="">
						  <option value="<?php echo @$county; ?>"><?php echo @$county; ?></option> 

						<?php 

				
				foreach ($counties as $key => $county) {
					?>
					 <option value="<?php echo @$county; ?>"><?php echo @$county; ?></option> 

					<?php
				}




				 ?>
					</select>

				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Police Station Category  <sup class="err fa fa-asterisk "></sup> </label>
				</div>
				<div class="col-sm-8">
					<select name="category"  class="form-control category">
					<option value="<?php echo $category; ?>"><?php echo $category; ?></option>

						<option value="CENTRAL">CENTRAL</option>
						<option value="DIVISION">DIVISION</option>
						<option value="LOCATION">LOCATION</option>
						<option value="SUB-LOCATION">SUB-LOCATION</option>
						
					</select>
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Reporting Date <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="date_of_arrest"  id="date_of_arrest" class="form-control" width="5cm;" value="<?php echo $date_of_arrest; ?>" >
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label">Reporter's Full Name <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="name" class="form-control" value="<?php echo $name; ?>" >
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label">Reporter's  Gender <sup class="err fa fa-asterisk "></sup> </label>
				</div>
				<div class="col-sm-8">
				<label><input type="radio" name="gender"  value="Male" <?php echo ($gender=="Male")?"checked='checked'":null; ?>  > Male </label>
				<label><input type="radio" name="gender"  value="Female" <?php echo ($gender=="Female")?"checked='checked'":null; ?>   > Female </label>
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label">Reporter's  Phone <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="reporter_phone" class="form-control" value="<?php echo $reporter_phone; ?>"  >
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label">Referee's  Phone <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="referees_phone" class="form-control" value="<?php echo $referees_phone; ?>"  >
				</div>
			</div>

			


			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label">Reporter's  ID Number </label>
				</div>
				<div class="col-sm-8">

				<input type="text" name="idnumber" class="form-control" value="<?php echo $idnumber; ?>"  >
				</div>
			</div>


			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Description  <sup class="err fa fa-asterisk "></sup> </label>
				</div>
				<div class="col-sm-8">

					<textarea class="form-control" name="desc" rows="10"><?php echo $desc; ?></textarea>
				
				</div>
			</div>


			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Reporting Police  Name <sup class="err fa fa-asterisk "></sup> </label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="police" class="form-control" value="<?php echo $police; ?>" >
				</div>
			</div>

		
				<div class="form-group">
				
				<div class="col-sm-12">
					<button class="btn btn-primary pull-right" name="reg_ob"> Save</button>
				</div>
			</div>




	</form>
		
		
	</div>
</div>