<?php 


$case_type=$subType=$fees=$type=null;



$message=$alert=null;

if (@$_GET['action']=="delete" && @$_GET['case_sub_type'] && @$_GET['case_type']) {
		$Server->query("delete from case_fees where case_sub_type=".$Server->quote($_GET['case_sub_type']) ." and  case_type=".$Server->quote($_GET['case_type']) ) or die($Server->error());
	} else if (@$_GET['action']=="update"  && @$_GET['case_sub_type'] && @$_GET['case_type'] ) 
	 {
		$selectSQL="select *  from case_fees where case_sub_type=".$Server->quote($_GET['case_sub_type']) ." and  case_type=".$Server->quote($_GET['case_type']) ;;// or die($Server->error());
		$selectSQL=$Server->select($selectSQL);

		foreach ($selectSQL as $key ) {
			
			$case_type=$key['case_type'];
			$type=$key['type'];
			$subType=$key['case_sub_type'];
			$fees=$key['fees'];
		}
	}

	
if (isset($_POST['case_fees'])) {
	
	$case_type=@$_POST['case_type'];
	$type=@$_POST['type'];
	$subType=@$_POST['subType'];
	$fees=@$_POST['fees'];

	$typeT=$subTypeT=false;

	
	if ($case_type && $type  && $subType )  {
		
		

			if ($type=="Fixed") {
				
					if ($validator->numbers($fees) ) {
						$typeT=true;
					} else {
						$message.="<br/>Please enter a valid Amount";
					}

					
			} else {
				$typeT=true;
			}



			if ($validator->userFullName($subType) ) {
						$subTypeT=true;
					} else {
						$message.="<br/>Please enter a valid Sub-Type Name";
					}

			



			//send to server
			if ($subTypeT && $typeT ) {

				$insertSQL="INSERT into case_fees ( case_type , case_sub_type ,type , fees ) values(
					".$Server->quote($case_type).",
					".$Server->quote($subType).",
					".$Server->quote($type).",
					".$Server->quote($fees)."


					)";

			if (@$_GET['action']=="update"  && @$_GET['case_sub_type'] && @$_GET['case_type'] )  
			{
					$insertSQL="UPDATE  case_fees set
					case_type=".$Server->quote($case_type).",
					case_sub_type=".$Server->quote($subType).",
					type=".$Server->quote($type).",
					fees=".$Server->quote($fees)."

					WHERE case_sub_type=".$Server->quote($_GET['case_sub_type']) ." and  case_type=".$Server->quote($_GET['case_type']); 



					
			}
				$insertSQL=$Server->query($insertSQL);// or die($Server->error());

				if ($insertSQL) {
					$Server-> commit();
					$alert="<br/>Details have been saved";

			if (@$_GET['action']=="update"  && @$_GET['case_sub_type'] && @$_GET['case_type'] )  
			
			{
				$AUTO_GEN->reload($Site-> site_url);
			}
			else
			{
				$AUTO_GEN->reload();
			}

					

				} else {
					$Server->rollback();
					$message.="<br/>Details have not been saved <br/>
						Please check that there is no duplicate entry of either <strong> CASE TYPE or CASE SUBTYPE </strong>
					";

				}
				
	
			}

			//end server;







	} else {
		$message.=  "<br/>Please provide all the details!!!";
	}
	
	
}



 ?>

<div class="row">
	
<div class="col-sm-4">
	

<div class="panel panel-primary">
	
<div class="panel-heading  text-center"> <h1> Set Case Fees </h1></div>
	
	<div class="panel-body">

		<?php 

				echo $msg=$message!=null?("<div class='alert alert-danger'> ".$message."</div>"):($alert?"<div class='alert alert-success'> $alert </div>":"");

			 ?>

	<form class="form-horizontal" method="post" action="">
		
		

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Case Type <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
					<select class="form-control" name='case_type'>
							
						<option value="<?php echo $case_type; ?>"><?php echo $case_type; ?></option>

						<?php 
							foreach ($AUTO_GEN-> case_type as $key => $case_type) {

								?>
								<option value="<?php echo strtoupper($case_type); ?>"><?php echo strtoupper($case_type); ?></option>

								<?php
								
							}

						 ?>

					</select>

				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Case Sub-Type <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="subType" class="form-control" value="<?php echo $subType; ?>" >
				</div>
			</div>

			
			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Fees Type <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
					
					<label class="control-label" > <input type="radio" value="Fixed" name='type' <?php echo strtolower($type)==strtolower("Fixed")?"checked='checked'":null; ?> onclick="javascript: loadCaseFees(this.value);"> Fixed </label>
					<label class="control-label" > <input type="radio" value="Optional" name='type' <?php echo strtolower($type)==strtolower("Optional")?"checked='checked'":null; ?>  onclick ="javascript: loadCaseFees(this.value);"> Optional </label>

				</div>
			</div>



			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Case Fees </label>
				</div>
				<div class="col-sm-8 display_case_fees">
					<input type="text" name="fees" readonly="readonly" class="form-control" placeholder="Enter Amount" value="<?php echo @$fees; ?>" >
				
				</div>
			</div>
			

		
				<div class="form-group">
				
				<div class="col-sm-12">
					<button class="btn btn-primary pull-right" name="case_fees"> Save</button>
				</div>
			</div>




	</form>
		
		
	</div>
</div>


</div>

<div class="col-sm-8">
	
	<div class="panel panel-primary">
	
<div class="panel-heading"> <h1> Case Fees Details </h1></div>
	
	<div class="panel-body">

	<table class="table table-resposive table-hover table-stripped">
		<thead>
			<tr>
				<th>#</th><th>CASE TYPE</th><th>CASE SUB-TYPE</th><th>FEES TYPE</th><th>FEES</th><th>&nbsp;</th>
			</tr>
		</thead>

		<tbody>
			<?php 
			$selectSQL="select * from case_fees order by case_type asc";
			$selectSQL=$Server->select($selectSQL);

			$k=1;

			foreach ($selectSQL as $key ) {
				?>

				<tr>
					<td><?php echo $k++; ?></td>
					<td><?php echo strtoupper($key['case_type']); ?></td>
					<td><?php echo strtoupper($key['case_sub_type']); ?></td>
					<td><?php echo strtoupper($key['type']); ?></td>
					<td><?php echo strtoupper($key['fees']); ?></td>
					<td>
						<div class="btn btn-group">
							<a href="?action=update&case_sub_type=<?php echo $key['case_sub_type']; ?>&case_type=<?php echo $key['case_type']; ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
							<a href="?action=delete&case_sub_type=<?php echo $key['case_sub_type']; ?>&case_type=<?php echo $key['case_type']; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>
						</div>
					</td>
				</tr>


				<?php
			}


			 ?>

		</tbody>
	</table>
		
		
	</div>
</div>
</div>
</div>



<script type="text/javascript">
	
function loadCaseFees (type) {

	
	$.post("views/caseFees.php",{ type : type }, function(data) {


		$('.display_case_fees').html(data);
	});
}

function loadCourt(county)
{
	$.post("views/list_county_by_court.php",{ county: county }, function(data) {
		$('.court').html(data);
	});
}

function checkWords(words, limit)
{
	$.post("views/desc_word_limit.php",{ words: words , limit: limit }, function(data) {
		$(".showNumberOfWords").html(data);
	});

	
}

</script>