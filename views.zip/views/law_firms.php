<?php 
	

	$name=$phone=$email=null;
	 $id=$AUTO_GEN -> uniqueNumber ;



	$idT=$nameT=$phoneT=$emailT=false;

	$message=$alert=null;
	
	if (@$_GET['action']=="delete" && @$_GET['id']) {
		$Server->query("delete from law_firms where firm_no=".$Server->quote($_GET['id'])) or die($Server->error());
	} else if (@$_GET['action']=="update" && @$_GET['id']) 
	 {
		$selectSQL="select * from law_firms where firm_no=".$Server->quote($_GET['id']);
		$selectSQL=$Server->select($selectSQL);

		foreach ($selectSQL as $key ) {
			
			$id=$key['firm_no'];
			$name=$key['name'];
			$email=$key['email'];
			$phone=$key['phone'];
		}
	}
	

	



	if (isset($_POST['reg_lawfirm'])) {
		
		$name=$_POST['name'];
		$phone=$_POST['phone'];
		$email=$_POST['email'];

		
		if ($name && $phone && $email ) {
			
			if ($validator->userFullName($name) ) {
				$nameT=true;
			} else {
				$message.="<br/>Please enter a valid name";
			}


			if ($validator->mult_email($email) ) {
				$emailT=true;
			} else {
				$message.= "<br/>Please enter a valid email address";
			}



			if ($validator->phone($phone) ) {
				$phoneT=true;
			} else {
				$message.= "<br/>Please enter a valid phone number";
			}


			if ($nameT && $phoneT && $emailT ) {

				$insertSQL="replace into law_firms ( firm_no,name, phone ,email) values(
					".$Server->quote($id).",
					".$Server->quote(strtoupper($name)).",
					".$Server->quote($phone).",
					".$Server->quote($email)."

					)";

			if (@$_GET['action']=="update" && @$_GET['id']) 
			{
				$insertSQL="update  law_firms set 
					
					name=".$Server->quote(strtoupper($name)).",
					phone=".$Server->quote($phone).",
					email=".$Server->quote($email)."

					where firm_no=".$Server->quote($_GET['id']);

					
			}
				$insertSQL=$Server->query($insertSQL) or die($Server->error());

				if ($insertSQL) {
					$Server-> commit();
					$alert="<br/>Details have been saved";

						if (@$_GET['action']=="update" && @$_GET['id']) 
			{
				$AUTO_GEN->reload($Site-> site_url);
			}
			else
			{
				$AUTO_GEN->reload();
			}

					

				} else {
					$Server->rollback();
					$alert="<br/>Details have not been saved <br/>
						Please check that there is no duplicate entry of either <strong> ID , Email or Phone </strong>
					";

				}
				
	
			}

			



		} else {
			
			$message.=  "<br/>Please provide all the details";
		}
		
		


	}


 ?>

<div class="row">
	<div class="col-sm-4">
		
		<div class="panel panel-primary">
	
<div class="panel-heading"> Registartion of Law Firms </div>
	
	<div class="panel-body">

			<?php 

				echo $msg=$message?("<div class='alert alert-danger'> ".$message."</div>"):($alert?"<div class='alert alert-success'> $alert </div>":"");

			 ?>
		
		<form class="form-horizontal" method="post" action="">
			
			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Firm ID </label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="id" class="form-control" value="<?php echo $id; ?>" readonly="readonly" >
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Name </label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="name" class="form-control" value="<?php echo $name; ?>">
				</div>
			</div>


			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Phone Number </label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="phone" class="form-control" value="<?php echo $phone; ?>">
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Email Address </label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="email" class="form-control" value="<?php echo $email; ?>">
				</div>
			</div>

			<div class="form-group">
				
				<div class="col-sm-12">
					<button class="btn btn-primary pull-right" name="reg_lawfirm"> Save</button>
				</div>
			</div>


		</form>

	</div>
</div>

	</div>
	<div class="col-sm-8">
		
	<div class="panel panel-info">
	
<div class="panel-heading"> Registered Law Firms</div>
	
	<div class="panel-body">

	<table class="table table-resposive table-hover table-stripped">
		<thead>
			<tr>
				<th>#</th><th>NAME</th><th>EMAIL ADDRESS</th><th>PHONE NUMBER</th><th>&nbsp;</th>
			</tr>
		</thead>

		<tbody>
			<?php 
			$selectSQL="select * from law_firms order by name asc";
			$selectSQL=$Server->select($selectSQL);

			$k=1;

			foreach ($selectSQL as $key ) {
				?>

				<tr>
					<td><?php echo $k++; ?></td>
					<td><?php echo strtoupper($key['name']); ?></td>
					<td><?php echo strtolower($key['email']); ?></td>
					<td><?php echo strtoupper($key['phone']); ?></td>
					<td>
						<div class="btn btn-group">
							<a href="?action=update&id=<?php echo $key['firm_no']; ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
							<a href="?action=delete&id=<?php echo $key['firm_no']; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>
						</div>
					</td>
				</tr>


				<?php
			}


			 ?>

		</tbody>
	</table>
		
		
	</div>
</div>

	</div>
</div>

