



<!-- COUNTY FOR CHAMBER && COURT -->

<div class="proceed_div_county">

					
					<select name="county" class="form-control county" onchange="javascript: loadCourtPreceedings( this.value );">
						  <option value="<?php echo @$county; ?>"><?php echo @$county; ?></option> 

						<?php 

				
				foreach ($counties as $key => $county) {
					?>
					 <option value="<?php echo @$county; ?>"><?php echo @$county; ?></option> 

					<?php
				}




				 ?>
					</select>

</div>
<!-- COURT  -->

<div class="proceed_court">
					Select County from above
</div>


<!-- COURT  room numbers -->

<div class="proceed_court_chamber_room_number">
					Select Court from above
</div>


<script type="text/javascript">
	
	$(document).ready(function(){

		

		$(".desc_list").change(function(){




			var destinationType=$(this).val();

		

			switch(destinationType)
			{	
				case 'REGISTRY':
					hide();
					
					$(".div_county").show();


				break;

				case 'COURT':
				case 'CHAMBER':
					hide();
					
					$(".div_county").show();


				break;

				case 'OTHERS':


					loadOthers("<?php echo @$others; ?>");

				break;

				default :
					show()();
				break;




			}





		});




	});



</script>