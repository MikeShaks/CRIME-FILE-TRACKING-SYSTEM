<?php 
$counties= $AUTO_GEN-> counties ;


$case_number=$AUTO_GEN-> uniqueNumber;

$case_type=$subType=$pfno=$county=$desc=$fees=null;

$case_typeT=$subTypeT=$pfnoT=$feesT=null;

$court=$courtName=null;

$number_of_rooms="SELECT A NUMBER";


$message=$alert=null;
	
if (isset($_POST['reg_case'])) {

	$_SESSION['case_tab']='case_reg';
	
	$case_type=@$_POST['case_type'];
	$case_number=@$_POST['case_number'];
	$subType=@$_POST['subType'];
	$pfno=@$_POST['pfno'];

	$court=@$_POST['court'];

		$courtName=@explode("$", $court);
		 $courtNo=@$courtName[0];
		 $courtName=@$courtName[1];

	$county=@$_POST['county'];
	$fees=@$_POST['fees'];

	$desc=@$_POST['desc'];
	
	if ($pfno && $case_type && $case_number  && $subType && $county && $fees && $desc && $court )  {
		
		
	
			if ($validator->numbers($fees) ) {
						$feesT=true;
					} else {
						$message.="<br/>Please enter a valid Case Fees Amount";
					}


			//send to server
			if ($feesT ) {

				$insertSQL="INSERT into case_reg_des ( case_type , case_sub_type, case_no ,case_year_filling , pf_no,
				 description, county, fees, court_no ) values(
					".$Server->quote($case_type).",
					".$Server->quote($subType).",
					".$Server->quote($case_number).",
					".$Server->quote('CURRENT_TIMESTAMP').",
					".$Server->quote($pfno).",

					".$Server->quote($desc).",
					".$Server->quote($county).",
					".$Server->quote($fees).",
					
					".$Server->quote($courtNo)."



					)";

			if (@$_GET['action']=="update" && @$_GET['id']) 
			{
					$insertSQL="UPDATE  case_reg_des SET
					case_type=".$Server->quote($case_type).",
					case_sub_type=".$Server->quote($subType).",
					case_year_filling".$Server->quote('CURRENT_TIMESTAMP').",
					pf_no=".$Server->quote($pfno).",

					description=".$Server->quote($desc).",
					county=".$Server->quote($county).",
					fees=".$Server->quote($fees).",
					court_no=".$Server->quote($courtNo)."

					WHERE case_no=".$Server->quote($case_number);


					
			}
				$insertSQL=$Server->query($insertSQL) ;//or die($Server->error());

				if ($insertSQL) {
					$Server-> commit();
					$alert="<br/>Details have been saved";

						if (@$_GET['action']=="update" && @$_GET['id']) 
			{
				$AUTO_GEN->reload($Site-> site_url);
			}
			else
			{
				$AUTO_GEN->reload();
			}

					

				} else {
					$Server->rollback();
					$message.="<br/>Details have not been saved <br/>
						Please check that there is no duplicate entry of either <strong> ID Number , Email or Phone </strong>
					";

				}
				
	
			}

			//end server;







	} else {
		$message.=  "<br/>Please provide all the details";
	}
	
	
}



 ?>




<div class="panel panel-primary">
	
<div class="panel-heading  text-center"> <h1> Case File Registartion</h1></div>
	
	<div class="panel-body">

		<?php 

				echo $msg=$message?("<div class='alert alert-danger'> ".$message."</div>"):($alert?"<div class='alert alert-success'> $alert </div>":"");

			 ?>

	<form class="form-horizontal" method="post" action="">
		
				<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Case Number </label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="case_number" class="form-control" value="<?php echo $case_number; ?>" readonly="readonly" >
				</div>
			</div>


			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Case Type <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
					<select class="form-control case_type" name='case_type'  onchange="javascript: case_sub_type( this.value );">
							
						<option value="<?php echo $case_type; ?>"><?php echo $case_type; ?></option>

						<?php

							$selectSQL="select distinct(case_type) as case_type  from case_fees ";
							$selectSQL=$Server->select($selectSQL);

							foreach ($selectSQL as $key ) {
								?>
								
								<option value="<?php echo strtoupper($key['case_type']); ?>"><?php echo strtoupper($key['case_type']); ?></option>

							<?php
							} 
							

						 ?>

					</select>

				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Case Sub-Type <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8  case_sub_type">
					Select A Case Type From Above
				</div>
			</div>

				

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Case Fees   <sup class="err fa fa-asterisk "></sup> </label>
				</div>
				<div class="col-sm-8 display_case_fees_case_reg">
					<input type="text" name="fees" readonly="readonly" class="form-control" placeholder="Enter Amount" value="<?php echo @$fees; ?>" >
				
				</div>
			</div>



			
			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Select PF Number <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
					
				<select name="pfno" class="form-control	pfno " onchange="javascript: getPFnumberDetails( this.value );">
					<option value="<?php echo $pfno; ?>"><?php echo $pfno; ?></option>
					
					<?php 

						$selectPfno="SELECT * from users";
						$selectPfno=$Server->query($selectPfno);

						foreach ($selectPfno as $key ) {
							?>
							<option value="<?php echo $key['pf_no']; ?>"> <?php echo $key['name']."   [ ".$key['pf_no']." ]"; ?></option>

							<?php
						}

					 ?>
					
				</select>

				</div>
			</div>


			



			<div class="form-group">
				<div class="col-sm-offset-4 col-sm-8 pfno_display">
					<p> Please select a PF Number</p>
				</div>
			</div>


			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Select County <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
					
					<select name="county" class="form-control county" onchange="javascript: loadCourt( this.value );">
						  <option value="<?php echo @$county; ?>"><?php echo @$county; ?></option> 

						<?php 

				
				foreach ($counties as $key => $county) {
					?>
					 <option value="<?php echo @$county; ?>"><?php echo @$county; ?></option> 

					<?php
				}




				 ?>
					</select>

				</div>
			</div>



				<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Select Court <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8 court">
					Select County from above
				</div>
			</div>

				<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Case Description <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">


					<div class="panel  panel-default">
						
						<div class="panel-body">
								<textarea class="form-control case_desc"  onkeyup="javascript: checkWords(this.value, 5); " rows="5" name="desc" placeholder="Enter some description." > <?php echo $desc; ?></textarea>
		
						</div>
						<div class="panel-footer showNumberOfWords">
							
						</div>
					</div>

				 		</div>
			</div>

			

			

			

		
				<div class="form-group">
				
				<div class="col-sm-12">
					<button class="btn btn-primary pull-right" name="reg_case"> Save</button>
				</div>
			</div>




	</form>
		
		
	</div>
</div>



