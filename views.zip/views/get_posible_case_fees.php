<?php 

include('../conf/conn.php');

 $case_number=$_POST['case_number'];

	  
		 $selectFees="SELECT fees from case_reg_des  where case_no=".$Server-> quote(explode("{", $case_number)[0]);
		 $selectFees=$Server-> select ($selectFees) ;//or die("error ".$Server-> error());

		
		if (count($selectFees)>0) {

			foreach ($selectFees as $key) {
				$fees=$key['fees'];

				?>
				<div class="btn btn-success "> Case fees is <strong><?php echo $fees; ?> Ksh.</strong> </div>

				<?php

				if ($fees>0) {
					
					?>

					<script type="text/javascript">
						
						$(document).ready(function(){
							$("input[name='amount']").removeAttr("disabled","disabled");
						});
					</script>

					<?php

				} else {
					?>

					<script type="text/javascript">
						
						$(document).ready(function(){
							$("input[name='amount']").attr("disabled","disabled").val("");
						});
					</script>

					<?php
				}
				
			}
		
		} else {
			
			?>

			<div class="label label-danger"> Fees not yet set </div>

			<?php
		}
		



