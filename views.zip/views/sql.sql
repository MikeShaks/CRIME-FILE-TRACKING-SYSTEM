

delimiter //

drop trigger if exists after_insert_on_court_reg//

create trigger after_insert_on_court_reg after insert on court_reg 
for each row 

begin 

	insert into registries ( court_id, commercial, traffic,children, family, land, sports, anti_corruption, political) values(
					
					new.id,0,0,0,0,0,0,0,0
					);

	insert into court_location (court_id) values (new.id);
	insert into court_room (court_id) values (new.id);

    insert into court_chambers (court_id) values (new.id);

end;

//


drop table if exists ozekimessagein;

CREATE TABLE ozekimessagein (
 id int(11) NOT NULL auto_increment,
  sender varchar(30) default NULL, 
  receiver varchar(30) default NULL,
   msg varchar(160) default NULL, 
   
   receivedtime varchar(100) default NULL,


PRIMARY KEY (id) ); 

drop table if exists ozekimessageout;

CREATE TABLE ozekimessageout ( 
	id int(11) NOT NULL auto_increment,
	 sender varchar(30) default NULL, 
	 receiver varchar(30) default NULL,
	  msg varchar(160) default NULL,
	   
	    status varchar(20) default NULL, 
	   
	      PRIMARY KEY (id) ); 

insert into ozekimessagein (operator,sender,receiver,msg,
senttime,receivedtime) values 
('$operator', '$sender','$receiver','$msg','$senttime',
'$receivedtime')

update ozekimessageout set status='received' where id='$id'

update ozekimessageout set status='transmitted',senttime='$senttime' where id='$id'

select id,receiver,msg,sender from ozekimessageout where status='send';


-- Connection ozeki string

Driver={MySQL ODBC 3.51 Driver};Server=localhost; Database=judiciary;User=root;Password=;Option=4;

-- End ozeki Connection string

drop table if exists ozekimessageout;


drop table if exists ozekimessagein;


CREATE TABLE ozekimessagein (
 id int(11) NOT NULL auto_increment, 
 sender varchar(30) default NULL,
 receiver varchar(30) default NULL, 
 msg varchar(160) default NULL, 
 senttime varchar(100) default NULL, 
	receivedtime varchar(100) default NULL, 
	operator varchar(100),
	 msgtype varchar(160) default NULL,
	 reference varchar(100) default NULL,
	 PRIMARY KEY (id) );  


CREATE TABLE ozekimessageout (
 id int(11) NOT NULL auto_increment,
  sender varchar(30) default NULL, 
	receiver varchar(30) default NULL,
	 msg varchar(160) default NULL, 
	 senttime varchar(100) default NULL,
	  receivedtime varchar(100) default NULL, 
	  reference varchar(100) default NULL, 
	  status varchar(20) default NULL, 
	  msgtype varchar(160) default NULL, 
	operator varchar(100),
	 PRIMARY KEY (id) );