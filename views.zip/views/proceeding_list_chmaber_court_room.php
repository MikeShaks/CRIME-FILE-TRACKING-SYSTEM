<?php 

include('../conf/conn.php');

$court=$_POST['court'];  

$room_no=@$_POST['roomno'];  





if ($court) {

			 $courtArray=explode("$", $court);
			 $courtNo=$courtArray[0];
		
		   	$table="court_room";

		  $sqlSelect="select room_no from ".$table."  where court_id=".$Server-> quote($courtNo);

		 $sqlSelect=$Server->select($sqlSelect) or die("errror ::".	$Server->error());


		


		 if (count($sqlSelect)>0) {

		 	 $numberofRooms=0;

		 	foreach ($sqlSelect as $key) {
		 		 $numberofRooms=$key['room_no'];
		 	}


		 	?>

		 	<select name="room_no" class="form-control room_number"  >

					     <option value="<?php echo @$room_no; ?>"><?php echo @$room_no; ?></option> 

					     <?php 
					   
							for($r=1; $r<=$numberofRooms; $r++){
					      
					      ?>
					      <option value="<?php echo $r; ?>"> <?php echo $r; ?> </option>

					      <?php
					      $name=$key['name'];
					      
					    }

					    ?>

					    </select>

					<?php
		 } else {
	?>

	<div class="alert alert-danger"> The court/ Chmaber has not been assigned a  room yet.</div>

	<?php
		 }
		 


} else {
	
	?>

	<div class="alert alert-danger"> Court Not Selected</div>

	<?php
}


 ?>

 <script type="text/javascript">
 	
 	$(".room_number").select2({
                    placeholder: "Select Room Number ",
                    allowClear: true
     });


 </script>