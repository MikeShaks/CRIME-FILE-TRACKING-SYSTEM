

<?php 

include('../conf/conn.php');

$pfno=@$_POST['pfno'];

$getUser=$Server->query("SELECT * from users where pf_no=".$Server->quote($pfno));

if (count($getUser)>0) {
	?>


<div class="alert alert-info">
 <table class="table table-resposive ">
 	
 	<thead>
 		<tr>
 			<th>PF Number</th> <th>Name</th><th>Gender</th><th>Type</th><th>Phone</th><th>Id Number</th>
 		</tr>
 	</thead>

 	<tbody>
 		
 	<?php 

 		foreach ($getUser as $key) {
 			
 			?>

 			<tr>
 				
 			<td><?php echo $key['pf_no']; ?></td>
 			<td><?php echo strtoupper($key['name']); ?></td>
 			<td><?php echo strtoupper($key['gender']); ?></td>
 			<td><?php echo strtoupper($key['type']); ?></td>
 			<td><?php echo $key['phone']; ?></td>
 			<td><?php echo $key['idnumber']; ?></td>
 		
 			</tr>

 			<?php
 		}

 	 ?>

 	</tbody>

 </table>

 </div>

	<?php
} else {
	?>

	<div class="alert alert-danger"> There are no details to be displayed for the user </br>

		The user details might be removed from the system.

	</div>

	<?php
}



 ?>

