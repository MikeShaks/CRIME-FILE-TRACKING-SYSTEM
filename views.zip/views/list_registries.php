<?php 

include('../conf/conn.php');

$court=$_POST['court'];

$registries=@$_POST['registries'];


 $sqlSelect="select * from registries where court_id=50";
 $sqlSelect=$Server->select($sqlSelect) ;//or die($Server->error());



$list_registries=null;

$i=0;
foreach ($sqlSelect as $key) {
	
	$commercial=$key['commercial']?" COMMERCIAL ,":null;
	$traffic=$key['traffic']?" TRAFFIC ,":null;
	$children=$key['children']?" CHILDREN ,":null;
	$family=$key['family']?" FAMILY ,":null;
	$land=$key['land']?" LAND ,":null;
	$sports=$key['sports']?" SPORTS ,":null;
	$anti_corruption=$key['anti_corruption']?" ANTI-CORRUPTION ,":null;
	$political=$key['political']?" POLITICAL ,":null;

	$i++;
}


     

 $list_registries.=$commercial.$traffic.$children.$family.$land.$sports.$anti_corruption.$political;

 if ($list_registries) {
 		
 		$list_registries=explode(",", $list_registries);

 		?>

 			<select name="registries" class="form-control list_registries" >

					     <option value="<?php echo @$registries; ?>"><?php echo @$registries; ?></option> 

					     <?php 
					   
					    for($y=0; $y<(count($list_registries)); $y++ ) {
					      
					      ?>
					      <option value="<?php echo $list_registries[$y]; ?>"> <?php echo  $list_registries[$y];; ?> </option>

					      <?php
					      
					    }

					    ?>

					    </select>

			<?php

 } else {
 	
 	?>
<div class="alert alert-danger"> Registries not found for the court </div>


	<?php
 }

 ?>
 






<script type="text/javascript">
	

	
	$(".court_list").select2({
                    placeholder: "Select court ",
                    allowClear: true
     });

$(".list_registries").select2({
                    placeholder: "Select A registry ",
                    allowClear: true
     });

	
</script>
