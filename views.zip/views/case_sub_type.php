<?php 

include('../conf/conn.php');

$case_type=$_POST['case_type'];

  

if ($case_type) {
		
		  
		  $sqlSelect="select case_sub_type from case_fees where case_type=".$Server->quote($case_type);
		 $sqlSelect=$Server->select($sqlSelect) ;//or die($Server->error());


		 if (count($sqlSelect)>0) {
		 	?>

		 	<select name="subType" class="form-control subT"  onchange="javascript: loadFees(this.value);">

					     <option value="<?php echo @$subType; ?>"><?php echo @$subType; ?></option> 

					     <?php 
					   
					    foreach ($sqlSelect as $key ) {
					      
					      ?>
					      <option value="<?php echo strtoupper($key['case_sub_type']); ?>"> <?php echo strtoupper($key['case_sub_type']); ?> </option>

					      <?php
					      
					    }

					    ?>

					    </select>

					<?php
		 } else {
	?>

	<div class="alert alert-danger"> Case Sub Type not found in <strong><?php echo strtoupper("Case Fees"); ?> </strong></div>

	<?php
		 }
		 


} else {
	
	?>

	<div class="alert alert-danger"> Case Type Not Selected</div>

	<?php
}


 ?>


<script type="text/javascript">
	

	 function loadFees (subType) {

		var case_type=$('.case_type').val();


	$.post("views/load_caseFees.php",{ case_type : case_type, subType: subType }, function(data) {


		$('.display_case_fees_case_reg').html(data);
	});
}
</script>