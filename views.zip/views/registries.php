<?php 
	



	$name=null;


	$court=$courtName=$commercial=$traffic=$children=$family=$political=$land=$sports=$anti_corruption=null;
	
	$nameT=false;

	$message=$alert=null;
	
	if (@$_GET['action']=="delete" && @$_GET['id']) {
		$Server->query("delete from registries where court_id=".$Server->quote($_GET['id'])) or die($Server->error());
	} 

	// else if (@$_GET['action']=="update" && @$_GET['id']) 
	//  {
	// 	$selectSQL="select * from court_reg where id=".$Server->quote($_GET['id']);
	// 	$selectSQL=$Server->select($selectSQL);

	// 	foreach ($selectSQL as $key ) {
			
			
	// 		$name=$key['name'];
			
	// 	}
	// }
	

	



	if (isset($_POST['reg_registries'])) {
		

		

		 $court=$_POST['court'];

		$courtName=@explode("$", $court);
		 $courtNo=@$courtName[0];
		 $courtName=@$courtName[1];

		$commercial=@$_POST['COMMERCIAL']?1:0;
		$traffic=@$_POST['TRAFFIC']?1:0;
		$children=@$_POST['CHILDREN']?1:0;
		$family=@$_POST['FAMILY']?1:0;


		$political=@$_POST['POLITICAL']?1:0;
		$sports=@$_POST['SPORTS']?1:0;
		$land=@$_POST['LAND']?1:0;
		$anti_corruption=@$_POST['ANTI_CORRUPTION']?1:0;



		if ($court  && ( $anti_corruption || $political || $sports || 
			$land || $family || $traffic || $commercial || $children  ) ) {
			
			$courtName=explode("$", $court);
		 $courtNo=$courtName[0];
		 $courtName=$courtName[1];




				$insertSQL="replace into registries ( court_id, commercial, traffic,children, family, land, sports, anti_corruption, political) values(
					
					".$Server->quote($courtNo).",

					".$Server->quote($commercial).",
					".$Server->quote($traffic).",
					".$Server->quote($children).",
					".$Server->quote($family).",

					".$Server->quote($land).",
					".$Server->quote($sports).",
					".$Server->quote($anti_corruption).",
					".$Server->quote($political)."


					
					)";

			if (@$_POST['reg_registries']=="update" && @$_POST['id']) 
			{
					$insertSQL="update  registries set 
					
					
					commercial=".$Server->quote($commercial).",
					traffic=".$Server->quote($traffic).",
					children=".$Server->quote($children).",
					family=".$Server->quote($family).",

					land=".$Server->quote($land).",
					sports=".$Server->quote($sports).",
					anti_corruption=".$Server->quote($anti_corruption).",
					political=".$Server->quote($political)."

					where court_id=".$Server->quote($courtNo);



					
			}
				$insertSQL=$Server->query($insertSQL) or die($Server->error());

				if ($insertSQL) {
					$Server-> commit();
					$alert="<br/>Details have been saved";

						if (@$_GET['action']=="update" && @$_GET['id']) 
			{
				$AUTO_GEN->reload($Site-> site_url);
			}
			else
			{
				$AUTO_GEN->reload();
			}

					

				} else {
					$Server->rollback();
					$alert="<br/>Details have not been saved <br/>
						Please check that there is no duplicate entry of either <strong> ID , Email or Phone </strong>
					";

				}
				
	
			

			



		} else {
			
			$message.=  "<br/>Please provide all the details";
		}
		
		


	}


 ?>

<div class="row">
	<div class="col-sm-4 registries_hide ">
		
		<div class="panel panel-primary">
	
<div class="panel-heading"> Registration of Registries </div>
	
	<div class="panel-body">

			<?php 

				echo $msg=$message?("<div class='alert alert-danger'> ".$message."</div>"):($alert?"<div class='alert alert-success'> $alert </div>":"");

			 ?>
		
		<form class="form-horizontal" method="post" action="">
			
			

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Select a Court </label>
				</div>
				<div class="col-sm-8">
				<?php  $AUTO_GEN-> courts($court, $courtName) ; ?>
				</div>
			</div>

				<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Registries </label>
				</div>
				<div class="col-sm-8">
				
					<label class="control-label "> <input type="checkbox" name="COMMERCIAL" value="COMMERCIAL " > COMMERCIAL</label> <br/>
					<label class="control-label"> <input type="checkbox" name="TRAFFIC" value="TRAFFIC" > TRAFIC</label> <br/>
					<label class="control-label"> <input type="checkbox" name="CHILDREN" value="CHILDREN" > CHILDREN</label> <br/>
					<label class="control-label"> <input type="checkbox" name="FAMILY" value="FAMILY" > FAMILY</label> <br/>


					<label class="control-label"> <input type="checkbox" name="LAND" value="LAND" > LAND</label> <br/>
					<label class="control-label"> <input type="checkbox" name="SPORTS" value="SPORTS " > SPORTS</label> <br/>
					<label class="control-label"> <input type="checkbox" name="ANTI_CORRUPTION" value="ANTI-CORRUPTION " > ANTI-CORRUPTION</label> <br/>
					<label class="control-label"> <input type="checkbox" name="POLITICAL" value="POLITICAL " > POLITICAL</label> <br/>




				</div>
			</div>


			

			<div class="form-group">
				
				<div class="col-sm-12">
					<button class="btn btn-primary pull-right" name="reg_registries"> Save</button>
				</div>
			</div>


		</form>

	</div>
</div>

	</div>
	<div class="col-sm-8 registries_show">
		
	<div class="panel panel-info">


	
<div class="panel-heading"> Registered Registries</div>
	
	<div class="panel-body registries_table" >

	<?php 

				echo $msg=$message?("<div class='alert alert-danger'> ".$message."</div>"):($alert?"<div class='alert alert-success'> $alert </div>":"");

			 ?>

	<table class="table table-resposive table-hover table-stripped">
		<thead>
			<tr>
				<th colspan="2">&nbsp;</th>
				<th colspan="9">REGISTRIES</th>
			</tr>
			<tr>
				<th>#</th><th>COURTS</th> 
				<th>COMMERCIAL</th>
				<th>TRAFFIC</th>
				<th>CHILDREN</th>
				<th>FAMILY</th>

				<th>LAND</th>
				<th>SPORTS</th>
				<th>ANTI-CORRUPTION </th>
				<th>POLITICAL</th>


				  <th>&nbsp;</th>
			</tr>
		</thead>

		<tbody>
			<?php 
			$selectSQL="select distinct(registries.court_id) as id ,registries.*,court_reg.name from registries,court_reg where court_reg.id=registries.court_id order by court_id asc";
			$selectSQL=$Server->select($selectSQL);

			$k=1;

			foreach ($selectSQL as $key ) {
				?>

				<tr>
				<form method="post" action="">
					<td><?php echo $k++; ?>


					</td>
					<td class="courts">  <?php 

					 $court=$key['court_id']."$".$key['name'];
					echo  $courtName=$key['name'];

					//$AUTO_GEN-> courts($court, $courtName,'readonly') ;


					$COMMERCIAL=$key['commercial']?"checked='checked'":"";
					$TRAFFIC=$key['traffic']?"checked='checked'":"";
					$CHILDREN=$key['children']?"checked='checked'":"";
					$FAMILY=$key['family']?"checked='checked'":"";

					$LAND=$key['land']?"checked='checked'":"";
					$SPORTS=$key['sports']?"checked='checked'":"";
					$ANTI_CORRUPTION=$key['anti_corruption']?"checked='checked'":"";
					$POLITICAL=$key['political']?"checked='checked'":"";

					
					?>

					</td>

					<td><label class="control-label "> <input type="checkbox" <?php echo $COMMERCIAL; ?> name="COMMERCIAL" value="COMMERCIAL " > </label> <br/>
					</td><td><label class="control-label"> <input type="checkbox" <?php echo $TRAFFIC; ?> name="TRAFFIC" value="TRAFFIC" > </label> <br/>
					</td><td><label class="control-label"> <input type="checkbox" <?php echo $CHILDREN; ?> name="CHILDREN" value="CHILDREN" > </label> <br/>
					</td><td><label class="control-label"> <input type="checkbox" <?php echo $FAMILY; ?> name="FAMILY" value="FAMILY" > </label> <br/>


					</td><td><label class="control-label"> <input type="checkbox" <?php echo $LAND; ?> name="LAND" value="LAND" > </label> <br/>
					</td><td><label class="control-label"> <input type="checkbox" <?php echo $SPORTS; ?> name="SPORTS" value="SPORTS " > </label> <br/>
					</td><td><label class="control-label"> <input type="checkbox" <?php echo $ANTI_CORRUPTION; ?> name="ANTI_CORRUPTION" value="ANTI-CORRUPTION " > </label> <br/>
					</td><td><label class="control-label"> <input type="checkbox" <?php echo $POLITICAL; ?> name="POLITICAL" value="POLITICAL " > </label> <br/>
					</td>

					
					<td>
					<input type="hidden" name="id" class="form-control" value="<?php echo $key['court_id']; ?>" readonly="readonly" >
					<input type="hidden" name="court" class="form-control" value="<?php echo $court; ?>" readonly="readonly" >
				
						<div class="btn btn-group">
							<button  class="btn btn-primary btn-sm" name="reg_registries" value="update"><i class="fa fa-edit"></i></button>
							<a href="?action=delete&id=<?php echo $key['court_id']; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>
						</div>
					</td>

					</form>
				</tr>


				<?php
			}


			 ?>

		</tbody>
	</table>
		
		
	</div>
</div>

	</div>
</div>


<script type="text/javascript">
	
$(document).ready(function(){
	$(".registries_hide").removeClass("col-sm-4").hide();
	$(".registries_show").removeClass("col-sm-8").addClass("col-sm-12");
});

</script>