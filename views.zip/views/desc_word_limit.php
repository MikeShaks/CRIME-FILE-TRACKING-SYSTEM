<?php 

include("../conf/conn.php");

 $words=trim($_POST['words']);

 $limit=$_POST['limit'];


 $wordsCount=str_word_count($words);

 


if ($wordsCount > $limit ) {

	$words=$validator-> setWordLimit($words, $limit);
	
	?>
	<script type="text/javascript">

 	$(document).ready(function(){

 		$(".case_desc").addClass(" alert alert-warning").val("<?php echo $words; ?>");

 		
 	});

 </script>


	<?php
} 
else
{
	?>
	<script type="text/javascript">

 	$(document).ready(function(){

 		$(".case_desc").removeClass(" alert alert-warning");

 		
 	});

 </script>


	<?php
}


 ?>

 <table class="table">
 	<tr>
 		<td>Words : <strong><?php echo $wordsCount; ?></strong> </td>

 		<td class="pull-right">Word Limit <strong><?php echo $limit; ?></strong></td>
 	</tr>
 </table>

