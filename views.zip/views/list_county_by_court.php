<?php 

include('../conf/conn.php');

$county=$_POST['county'];
$court=$_POST['court'];

$courtArray=explode("$",$court);

$courtName=@$courtArray[1];
  

if ($county) {
		
		   $countyKey=$AUTO_GEN-> keys($county)[0];

		  $sqlSelect="select court_reg.* from court_location,court_reg where ".$countyKey."<>0 and court_reg.id=court_location.court_id";
		 $sqlSelect=$Server->select($sqlSelect) ;//or die($Server->error());


		 if (count($sqlSelect)>0) {
		 	?>

		 	<select name="court" class="form-control court_list"  >

					     <option value="<?php echo @$court; ?>"><?php echo @$courtName; ?></option> 

					     <?php 
					   
					    foreach ($sqlSelect as $key ) {
					      
					      ?>
					      <option value="<?php echo $key['id']."$".$key['name']; ?>"> <?php echo $key['name']; ?> </option>

					      <?php
					      $name=$key['name'];
					      
					    }

					    ?>

					    </select>

					<?php
		 } else {
	?>

	<div class="alert alert-danger"> Court not found in <strong><?php echo strtoupper($county); ?> </strong> County.</div>

	<?php
		 }
		 


} else {
	
	?>

	<div class="alert alert-danger"> County Not Selected</div>

	<?php
}


 ?>

<script type="text/javascript">
	

	
	$(".court_list").select2({
                    placeholder: "Select court ",
                    allowClear: true
     });


	$('.court_list').change(function(){

			
			var court=$(".court_list").val();

			var destinationType=$(".desc_list").val();

			switch(destinationType)
			{
				case 'REGISTRY':

					loadRegistries(court);


				break;
				case 'COURT':
				case 'CHAMBER':
						loadCourtChamberRoomNo(court);
		
				break;

				default :
					loadCourtChamberRoomNo(court);
				break;


			}

			
			
		});









</script>
