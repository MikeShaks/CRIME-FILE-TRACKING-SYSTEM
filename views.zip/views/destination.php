


<select name="desc_list" class="form-control desc_list">
	
	<option value="<?php echo @$desc_list; ?>"><?php   echo @$desc_list; ?></option>
	<option value="CHAMBER">CHAMBER</option>
	<option value="COURT">COURT</option>
	<option value="REGISTRY">REGISTRY</option>
	<option value="OTHERS">OTHERS</option>


</select>

<!-- COUNTY FOR CHAMBER && COURT -->

<div class="div_county">

					
					<select name="county" class="form-control county" onchange="javascript: loadCourt( this.value );">
						  <option value="<?php echo @$county; ?>"><?php echo @$county; ?></option> 

						<?php 

				
				foreach ($counties as $key => $county) {
					?>
					 <option value="<?php echo @$county; ?>"><?php echo @$county; ?></option> 

					<?php
				}




				 ?>
					</select>

</div>
<!-- COURT  -->

<div class="court">
					Select County from above
</div>


<!-- COURT  room numbers -->

<div class="court_chamber_room_number">
					Select Court from above
</div>


<!-- COURT  Registries-->

<div class="court_registries">
					Select Court from above
</div>

<!-- Others   -->

<div class="others">
					Select A registry
</div>


<script type="text/javascript">
	
	$(document).ready(function(){

		

		$(".desc_list").change(function(){




			var destinationType=$(this).val();

		

			switch(destinationType)
			{	
				case 'REGISTRY':
					hide();
					
					$(".div_county").show();


				break;

				case 'COURT':
				case 'CHAMBER':
					hide();
					
					$(".div_county").show();


				break;

				case 'OTHERS':


					loadOthers("<?php echo @$others; ?>");

				break;

				default :
					hide();
				break;




			}





		});




	});



</script>