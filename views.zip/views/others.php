<?php 

$others=@$_POST['others'];

 ?>

<input type="text" class="form-control others_input" name="others" value="<?php echo @$others; ?>" placeholder="Enter some description">