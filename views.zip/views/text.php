<div class="panel panel-primary">
	
<div class="panel-heading"> Registartion of Law Firms </div>
	
	<div class="panel-body">
		
		
	</div>
</div>



	<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Divison ID </label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="id" class="form-control" value="<?php echo $id; ?>" readonly="readonly" >
				</div>
			</div>














			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Select County <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
					
					<select name="county" class="form-control county" onchange="javascript: loadCourt( this.value );">
						  <option value="<?php echo @$county; ?>"><?php echo @$county; ?></option> 

						<?php 

				
				foreach ($counties as $key => $county) {
					?>
					 <option value="<?php echo @$county; ?>"><?php echo @$county; ?></option> 

					<?php
				}




				 ?>
					</select>

				</div>
			</div>



				<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Select Court <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8 court">
					Select County from above
				</div>
			</div>


<input type="text" name="destination" class="form-control" value="<?php echo $destination; ?>" >
				