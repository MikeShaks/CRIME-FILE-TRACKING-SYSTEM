<?php 
	
	

	$name=$court=$courtName=$number_of_rooms=null;

	$number_of_rooms="SELECT A NUMBER";


	

	$roomT=false;

	$message=$alert=null;
	
	if (@$_GET['action']=="delete" && @$_GET['id']) {
		$Server->query("delete from court_reg where id=".$Server->quote($_GET['id'])) or die($Server->error());
	} else if (@$_GET['action']=="update" && @$_GET['id']) 
	 {
		$selectSQL="select * from court_reg where id=".$Server->quote($_GET['id']);
		$selectSQL=$Server->select($selectSQL);

		foreach ($selectSQL as $key ) {
			
			
			$name=$key['name'];
			
		}
	}
	

	



	if (isset($_POST['update_court_rooms'])) {
		
		 $number_of_rooms=$_POST['number_of_rooms'];
		
		 $court=@$_POST['court'];

		$courtName=@explode("$", $court);
		 $courtNo=@$courtName[0];
		 $courtName=@$courtName[1];
		
		if ($court && $number_of_rooms  ) {
			
			if ($validator->numbers($number_of_rooms) ) {
				$roomT=true;
			} else {
				$message.="<br/>Please enter a valid Room Number <stong>( Must be WHOLE numbers )</stong>";
			}





			
			if ($roomT ) {

				

				$insertSQL="update  court_room set 
					
				
					room_no=".$Server->quote(strtoupper($number_of_rooms))."
					
				
					where court_id=".$Server->quote($_POST['id']);

					
			
				$insertSQL=$Server->query($insertSQL) or die($Server->error());

				if ($insertSQL) {
					$Server-> commit();
					$alert="<br/>Details have been saved";

					
				$AUTO_GEN->reload();
			

					

				} else {
					$Server->rollback();
					$alert="<br/>Details have not been saved <br/>
						Please check that there is no duplicate entry of either <strong> ROOM NUMBER </strong>
					";

				}
				
	
			}

			



		} else {
			
			$message.=  "<br/>Please provide all the details";
		}
		
		


	}


 ?>

<div class="row">
	
	<div class="col-sm-12">
		
	<div class="panel panel-info">
	
<div class="panel-heading"> Registered Court Rooms </div>
	
	<div class="panel-body">

	<?php 

				echo $msg=$message?("<div class='alert alert-danger'> ".$message."</div>"):($alert?"<div class='alert alert-success'> $alert </div>":"");

			 ?>

	
	<table class="table table-resposive table-hover table-stripped">
		<thead>
			
			<tr>
				<th>#</th><th>COURTS</th> 
				<th>NUMBER OF ROOMS</th>
			

				  <th>&nbsp;</th>
			</tr>
		</thead>

		<tbody>
			<?php 
			$selectSQL="select  court_room.*,court_reg.name from court_room,court_reg where court_reg.id=court_room.court_id order by court_id asc";
			$selectSQL=$Server->select($selectSQL);

			$k=1;

			foreach ($selectSQL as $key ) {
				?>

				<tr>
				<form method="post" action="">
					<td><?php echo $k++; ?>


					</td>
					<td class="courts">  <?php 

					 $court=$key['court_id']."$".$key['name'];
					echo  $courtName=$key['name'];


					$number_of_rooms=$key['room_no']?$key['room_no']:"SELECT A NUMBER";;

				
					?>

					</td>

					<!-- <td><label class="control-label "> <input type="text" name="number_of_rooms" value="<?php echo $number_of_rooms; ?> " > </label> <br/> -->
					
					<td>
						<select class="form-control" name="number_of_rooms">
							<option value="<?php echo $number_of_rooms; ?>"><?php echo $number_of_rooms; ?></option>
							<?php 

							for($x=1; $x<=100; $x++)
							{

								?>
								<option value="<?php echo $x; ?>"><?php echo $x; ?></option>
								<?php
							}

							 ?>
						</select>
					</td>

					
					<td>
					<input type="hidden" name="id" class="form-control" value="<?php echo $key['court_id']; ?>" readonly="readonly" >
					<input type="hidden" name="court" class="form-control" value="<?php echo $court; ?>" readonly="readonly" >
				
						<div class="btn btn-group">
							<button  class="btn btn-primary btn-sm" name="update_court_rooms" value="update"><i class="fa fa-edit"></i> Update</button>
							</div>
					</td>

					</form>
				</tr>


				<?php
			}


			 ?>

		</tbody>
	</table>
		
		
	</div>
</div>

	</div>
</div>

