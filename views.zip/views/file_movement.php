<?php 
$counties= $AUTO_GEN-> counties ;

 

$file_number=$moved_date=$file_receiver=$date_received=$reasons=$file_status=null;


$others=$destination=$county=$court=$desc_list=$room_no=$registries=null;

//destination
$desc_list=null;

$DestinationT=false;

$message=$alert=null;
	
if (isset($_POST['file_movement'])) {


		$file_number=@$_POST['file_number'];
		$moved_date=@$_POST['moved_date'];
		$file_receiver=@$_POST['file_receiver'];
		$date_received=@$_POST['date_received'];
		$reasons=@$_POST['reasons'];

		$file_status=@$_POST['file_status'];

		// DESTINATION 

		$others=@$_POST['others'];
		$county=@$_POST['county'];
		 $court=@$_POST['court'];
		 $desc_list=@$_POST['desc_list'];
		$room_no=@$_POST['room_no'];
		 $registries=@$_POST['registries'];

	
		if($file_number && $moved_date && $file_receiver && $date_received && $reasons && $file_status && $desc_list){

			
				switch ($desc_list) {

					case "OTHERS":
				
				$county=$court=$room_no=$registries=null;

				if ($others) {




				 	$destination=" DESTINATION TYPE : ".$desc_list. " |  REASONS : ".$others;
					
					$DestinationT=true;
					?>
					<script type="text/javascript">
						loadOthers("<?php echo @$others; ?>");
					</script>

					<?php
				}
				else
				{
					$message="Please enter some description";
					?>
					<script type="text/javascript">
						loadOthers("<?php echo @$others; ?>");
					</script>

					<?php
				}

					break;

					case 'REGISTRY':


						?>
						<script type="text/javascript">
							$(document).ready(function(){
								show();
								$(".court_chamber_room_number, .others").hide();

								loadCourt('<?php echo $county; ?>','<?php echo $court; ?>');

								loadRegistries('<?php echo $court; ?>','<?php echo $registries; ?>');
							});

						</script>


						<?php


						if ($county  && $court && $registries) {


							 $destination=" DESTINATION TYPE : ".$desc_list." | COUNTY : ".$county." |  COURT : ".explode("$",$court)[1]." | REGISTRY : ".$registries;

							
					
							$DestinationT=true;
		
						}
						else
						{
							$message="Please enter Select all the Destinations";
							
						}





					break;


					case 'COURT':
					case 'CHAMBER':


						?>
						<script type="text/javascript">
							$(document).ready(function(){
								show();
								$(".court_registries, .others").hide();

								loadCourt('<?php echo $county; ?>','<?php echo $court; ?>');

								 loadCourtChamberRoomNo('<?php echo $court; ?>', '<?php echo $room_no; ?>');
							});

						</script>


						<?php


						if ($county  && $court && $room_no) {


							$destination=$desc_list.$county.$court.$room_no;

								 $destination=" DESTINATION TYPE : ".$desc_list." |  COUNTY : ".$county." |  COURT : ".explode("$",$court)[1]." |  ROOM NUMBER : ".$room_no;

								$DestinationT=true;
		
						}
						else
						{
							$message="Please enter Select all the Destinations";
							
						}




					break;






			
			} // END SWITCH CASE



			//send to server
			if($DestinationT){

				$insertSQL="INSERT into file_movement ( file_no, date_moved, reason, status, destination, receiver, date_received ) values(
					".$Server->quote(explode("{",$file_number)[0]).",
					".$Server->quote($moved_date).",
					".$Server->quote($reasons).",
					".$Server->quote($file_status).",
					
					".$Server->quote($destination).",
					".$Server->quote($file_receiver).",
					".$Server->quote($date_received)."
					
					)";

		
				$insertSQL=$Server->query($insertSQL);// or die($Server->error());

				if ($insertSQL) {
					$Server-> commit();
					$alert="<br/>Details have been saved";



						if (@$_GET['action']=="update" && @$_GET['id']) 
			{
				$AUTO_GEN->reload($Site-> site_url);
			}
			else
			{
				
				$AUTO_GEN->reload();


			}

					

				} else {
					$Server->rollback();
					$message.="<br/>Details have not been saved <br/>
						Please check that there is no duplicate entry of either <strong> ID Number , Email or Phone </strong>
					";

				}
				
	
			}

			//end server;







	} else {
		$message.=  "<br/>Please provide all the details";
	}
	
	
}



 ?>




<div class="panel panel-primary">
	
<div class="panel-heading"> <h1> Case File Movements</h1> </div>
	
	<div class="panel-body">

		<?php 

				echo $msg=$message?("<div class='alert alert-danger'> ".$message."</div>"):($alert?"<div class='alert alert-success'> $alert </div>":"");

			 ?>

	<form class="form-horizontal" method="post" action="">
		

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> File Number  <sup class="err fa fa-asterisk "></sup> </label>
				</div>
				<div class="col-sm-8">
				
					<select name="file_number" class="form-control	file_number ">
					<option value="<?php echo $file_number; ?>"><?php echo $file_number; ?></option>
					
					<?php 

						$selectPfno="SELECT * from case_reg_des";
						$selectPfno=$Server->select($selectPfno);

						foreach ($selectPfno as $key ) {
							?>
							<option value="<?php echo $key['case_no']." { ".$key['case_type']." > ".$key['case_sub_type']; ?>"> <?php echo $key['case_no']." { ".$key['case_type']." > ".$key['case_sub_type']; ?></option>

							<?php
						}

					 ?>
					
				</select>


				</div>
			</div>

			

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> File Status  <sup class="err fa fa-asterisk "></sup> </label>
				</div>
				<div class="col-sm-8">
					<select name="file_status"  class="form-control file_status">
					<option value="<?php echo $file_status; ?>"><?php echo $file_status; ?></option>

						<option value="ACTIVE">ACTIVE</option>
						<option value="DORMANT">DORMANT</option>
						
					</select>
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Moved Date <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="moved_date"  id="moved_date" class="form-control" width="5cm;" value="<?php echo $moved_date; ?>" >
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Reason <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="reasons" class="form-control" value="<?php echo $reasons; ?>" >
				</div>
			</div>



			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label">Destination <sup class="err fa fa-asterisk "></sup> </label>
				</div>
				<div class="col-sm-8">
						
						<?php include_once 'destination.php'; ?>

				</div>
			</div>




			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Select File Receiver PF Number <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
					
				<select name="file_receiver" class="form-control	file_receiver " onchange="javascript: getPFnumberDetails( this.value );">
					<option value="<?php echo $file_receiver; ?>"><?php echo $file_receiver; ?></option>
					
					<?php 

						$selectPfno="SELECT * from users";
						$selectPfno=$Server->query($selectPfno);

						foreach ($selectPfno as $key ) {
							?>
							<option value="<?php echo $key['pf_no']; ?>"> <?php echo $key['name']."   [ ".$key['pf_no']." ]"; ?></option>

							<?php
						}

					 ?>
					
				</select>

				</div>
			</div>


			<div class="form-group">
				<div class="col-sm-offset-4 col-sm-8 pfno_display">
					<p> Please select a PF Number</p>
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Date Received <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="date_received" class="form-control" value="<?php echo $date_received; ?>"  >
				</div>
			</div>

			



			


		
				<div class="form-group">
				
				<div class="col-sm-12">
					<button class="btn btn-primary pull-right" name="file_movement"> Save</button>
				</div>
			</div>




	</form>
		
		
	</div>
</div>




<script type="text/javascript">
	
// 	function getPFnumberDetails (pfno) {

// 	$.post("views/pfno_details.php",{ pfno: pfno }, function(data) {
// 		$('.pfno_display').html(data);
// 	});
// }
</script>