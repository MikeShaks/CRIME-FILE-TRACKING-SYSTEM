<?php 
	
  $type=@$_POST['type'];

	$type=$type?($type=="Fixed" ? null :"readonly=\"readonly\""):"readonly=\"readonly\"";

 ?>

 <input type="text" name="fees" <?php echo $type; ?> class="form-control" placeholder="Enter Amount" value="<?php echo @$fees; ?>" >
				