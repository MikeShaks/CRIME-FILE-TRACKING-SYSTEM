1<?php 
	
	$counties= $AUTO_GEN-> counties ;


	$name=null;


	$court=$courtName=$commercial=$traffic=$children=$family=$political=$land=$sports=$anti_corruption=null;
	
	$nameT=false;

	$message=$alert=null;
	
	if (@$_GET['action']=="delete" && @$_GET['id']) {
		$Server->query("delete from court_location where court_id=".$Server->quote($_GET['id'])) or die($Server->error());
	} 


	



	if (isset($_POST['update_court_location'])) {
		

		 $court=$_POST['court'];

		$courtName=@explode("$", $court);
		 $courtNo=@$courtName[0];
		 $courtName=@$courtName[1];

		 foreach ($counties as $countiesKey => $county) {
		 	
		 	  $countyKey=$AUTO_GEN-> keys($county)[0];

		 	   $countyKeyValue=@$_POST[$countyKey]?1:0;


		 	  	if (@$_POST['update_court_location']=="update" && @$_POST['id']) 
			{
					$insertSQL="update  court_location set 
					
					
					".$countyKey."=".$Server->quote($countyKeyValue)." 
					
					where court_id=".$Server->quote($courtNo);



					
			}
				$insertSQL=$Server->query($insertSQL) or die($Server->error());

				if ($insertSQL) {
					$Server-> commit();
					$alert="<br/>Details have been saved";

			
			
				$AUTO_GEN->reload();
		
					

				} else {
					$Server->rollback();
					$alert="<br/>Details have not been saved <br/>
						
					";

				}
		

		 }

		
		


	}


 ?>

<div class="row">
	
	<div class="col-sm-12">
		
	<div class="panel panel-info">


	
<div class="panel-heading"> Registered Registries</div>
	
	<div class="panel-body registries_table" >

	<?php 

				echo $msg=$message?("<div class='alert alert-danger'> ".$message."</div>"):($alert?"<div class='alert alert-success'> $alert </div>":"");

			 ?>

	<table class="table table-resposive table-hover table-stripped">
		<thead>
			<tr>
				<th colspan="2">&nbsp;</th>
				<th colspan="<?php echo  (count($counties)+1); ?>">COUNTIES</th>
			</tr>
			<tr>
				<th>#</th><th>COURTS</th> 
				

				<?php 

				
				foreach ($counties as $key => $county) {
					?>
					<th><?php echo  ucwords($county); ?></th>

					<?php
				}




				 ?>


				  <th class="table-actions">&nbsp;</th>
			</tr>
		</thead>

		<tbody>
			<?php 
			$selectSQL="select court_location.*,court_reg.name from court_reg , court_location where court_reg.id=court_location.court_id order by court_id asc";
			$selectSQL=$Server->select($selectSQL) or die($Server-> error());

			$k=1;

			foreach ($selectSQL as $key ) {
				?>

				<tr>
				<form method="post" action="">
					<td><?php echo $k++; ?>


					</td>
					<td class="courts">  <?php 

					 $court=$key['court_id']."$".$key['name'];
					echo  $courtName=$key['name'];

					?>

					</td>

					<?php 
					foreach ($counties as $countiesKey => $county) {

						 $countyKey=$AUTO_GEN-> keys($county)[0];

						$checked=$key[$countyKey]?"checked='checked'":"";
					

						
					?>
					<td>
					<label class="control-label "> <input type="checkbox" <?php echo $checked; ?> name="<?php echo $countyKey; ?>" value="<?php echo $countyKey; ?>" > </label> <br/>
					</td>
					<?php 

						}
					 ?>

					
					<td class="table-actions">
					<input type="hidden" name="id" class="form-control" value="<?php echo $key['court_id']; ?>" readonly="readonly" >
					<input type="hidden" name="court" class="form-control" value="<?php echo $court; ?>" readonly="readonly" >
				
						<div class="btn btn-group">
							<button  class="btn btn-primary btn-sm" name="update_court_location" value="update"><i class="fa fa-edit"></i></button>
							<!-- <a href="?action=delete&id=<?php echo $key['court_id']; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a> -->
						</div>
					</td>

					</form>
				</tr>


				<?php
			}


			 ?>

		</tbody>
	</table>
		
		
	</div>
</div>

	</div>
</div>


<script type="text/javascript">
	
$(document).ready(function(){
	$(".registries_hide").removeClass("col-sm-4").hide();
	$(".registries_show").removeClass("col-sm-8").addClass("col-sm-12");
});

</script>