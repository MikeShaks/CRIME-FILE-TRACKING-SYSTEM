<?php 
$counties= $AUTO_GEN-> counties ;

 

$file_number=$action_to=$outcome=null;


$county=$court=$room_no=null;

$message=$alert=null;
	
if (isset($_POST['case_proceedings'])) {


		$file_number=@$_POST['file_number'];
				$action_to=@$_POST['action_to'];
				$outcome=@$_POST['outcome'];
		
		
				$county=@$_POST['county'];
				 $court=@$_POST['court'];
		$room_no=@$_POST['room_no'];
		 
	
		if($file_number && $county && $action_to && $outcome && $court && $room_no){

			
				?>
						<script type="text/javascript">
							$(document).ready(function(){
								proceedings_show();

								loadCourtPreceedings('<?php echo $county; ?>','<?php echo $court; ?>');

								 proceedingsloadCourtChamberRoomNo('<?php echo $court; ?>', '<?php echo $room_no; ?>');
							});

						</script>


						<?php
	

			//send to server
			

				$insertSQL="INSERT into proceedings ( court_room, actioned_to, outcome, file_no, court_id, location ) values(
				
					".$Server->quote($room_no).",
					".$Server->quote($action_to).",
					".$Server->quote($outcome).",
					
					".$Server->quote(explode("{",$file_number)[0]).",
					".$Server->quote(explode("$",$court)[0]).",
					".$Server->quote($county)."
					
					)";

		
				$insertSQL=$Server->query($insertSQL) or die($Server->error());

				if ($insertSQL) {
					$Server-> commit();
					$alert="<br/>Details have been saved";



						if (@$_GET['action']=="update" && @$_GET['id']) 
			{
				$AUTO_GEN->reload($Site-> site_url);
			}
			else
			{
				
				$AUTO_GEN->reload();


			}

					

				} else {
					$Server->rollback();
					$message.="<br/>Details have not been saved <br/>
						
					";

				}
				
	

			//end server;







	} else {
		$message.=  "<br/>Please provide all the details";
	}
	
	
}



 ?>




<div class="panel panel-primary">
	
<div class="panel-heading"> <h1> Case Proceedings</h1> </div>
	
	<div class="panel-body">

		<?php 

				echo $msg=$message?("<div class='alert alert-danger'> ".$message."</div>"):($alert?"<div class='alert alert-success'> $alert </div>":"");

			 ?>

	<form class="form-horizontal" method="post" action="">
		

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> File Number  <sup class="err fa fa-asterisk "></sup> </label>
				</div>
				<div class="col-sm-8">
				
					<select name="file_number" class="form-control	file_number ">
					<option value="<?php echo $file_number; ?>"><?php echo $file_number; ?></option>
					
					<?php 

						$selectPfno="SELECT * from case_reg_des where case_no  in ( select file_no from file_movement)";
						$selectPfno=$Server->query($selectPfno);

						foreach ($selectPfno as $key ) {
							?>
							<option value="<?php echo $key['case_no']." { ".$key['case_type']." > ".$key['case_sub_type']; ?>"> <?php echo $key['case_no']." { ".$key['case_type']." > ".$key['case_sub_type']; ?></option>

							<?php
						}

					 ?>
					
				</select>


				</div>
			</div>



			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Court <sup class="err fa fa-asterisk "></sup> </label>
				</div>
				<div class="col-sm-8">
						
						<?php include_once 'proceeding_court.php'; ?>

				</div>
			</div>

			

			

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Action To  <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="action_to"  class="form-control" value="<?php echo $action_to; ?>" >
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Outcome <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="outcome" class="form-control" value="<?php echo $outcome; ?>" >
				</div>
			</div>





			

			


		
				<div class="form-group">
				
				<div class="col-sm-12">
					<button class="btn btn-primary pull-right" name="case_proceedings"> Save</button>
				</div>
			</div>




	</form>
		
		
	</div>
</div>



