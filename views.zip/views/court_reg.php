<?php 
	

	$name=null;
	

	$nameT=false;

	$message=$alert=null;
	
	if (@$_GET['action']=="delete" && @$_GET['id']) {
		$Server->query("delete from court_reg where id=".$Server->quote($_GET['id'])) or die($Server->error());
	} else if (@$_GET['action']=="update" && @$_GET['id']) 
	 {
		$selectSQL="select * from court_reg where id=".$Server->quote($_GET['id']);
		$selectSQL=$Server->select($selectSQL);

		foreach ($selectSQL as $key ) {
			
			
			$name=$key['name'];
			
		}
	}
	

	



	if (isset($_POST['reg_courts'])) {
		
		$name=$_POST['name'];
		
		
		if ($name  ) {
			
			if ($validator->userFullName($name) ) {
				$nameT=true;
			} else {
				$message.="<br/>Please enter a valid name";
			}





			
			if ($nameT ) {

				$insertSQL="replace into court_reg (name) values(
					
					".$Server->quote(strtoupper($name))."
					
					)";

			if (@$_GET['action']=="update" && @$_GET['id']) 
			{
				$insertSQL="update  court_reg set 
					
					name=".$Server->quote(strtoupper($name))."
				
					where id=".$Server->quote($_GET['id']);

					
			}
				$insertSQL=$Server->query($insertSQL) or die($Server->error());

				if ($insertSQL) {
					$Server-> commit();
					$alert="<br/>Details have been saved";

						if (@$_GET['action']=="update" && @$_GET['id']) 
			{
				$AUTO_GEN->reload($Site-> site_url);
			}
			else
			{
				$AUTO_GEN->reload();
			}

					

				} else {
					$Server->rollback();
					$alert="<br/>Details have not been saved <br/>
						Please check that there is no duplicate entry of either <strong> ID , Email or Phone </strong>
					";

				}
				
	
			}

			



		} else {
			
			$message.=  "<br/>Please provide all the details";
		}
		
		


	}


 ?>

<div class="row">
	<div class="col-sm-4">
		
		<div class="panel panel-primary">
	
<div class="panel-heading"> Registartion of Courts </div>
	
	<div class="panel-body">

			<?php 

				echo $msg=$message?("<div class='alert alert-danger'> ".$message."</div>"):($alert?"<div class='alert alert-success'> $alert </div>":"");

			 ?>
		
		<form class="form-horizontal" method="post" action="">
			
			

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Name </label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="name" class="form-control" value="<?php echo $name; ?>">
				</div>
			</div>


			

			<div class="form-group">
				
				<div class="col-sm-12">
					<button class="btn btn-primary pull-right" name="reg_courts"> Save</button>
				</div>
			</div>


		</form>

	</div>
</div>

	</div>
	<div class="col-sm-8">
		
	<div class="panel panel-info">
	
<div class="panel-heading"> Registered Courts</div>
	
	<div class="panel-body">

	<table class="table table-resposive table-hover table-stripped">
		<thead>
			<tr>
				<th>#</th><th>NAME</th><th>&nbsp;</th>
			</tr>
		</thead>

		<tbody>
			<?php 
			$selectSQL="select * from court_reg order by name asc";
			$selectSQL=$Server->select($selectSQL);

			$k=1;

			foreach ($selectSQL as $key ) {
				?>

				<tr>
					<td><?php echo $k++; ?></td>
					<td><?php echo strtoupper($key['name']); ?></td>
					
					<td>
						<div class="btn btn-group">
							<a href="?action=update&id=<?php echo $key['id']; ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
							<a href="?action=delete&id=<?php echo $key['id']; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>
						</div>
					</td>
				</tr>


				<?php
			}


			 ?>

		</tbody>
	</table>
		
		
	</div>
</div>

	</div>
</div>

