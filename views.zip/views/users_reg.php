<?php 


$pfno=$AUTO_GEN-> uniqueNumber;

$name=$gender=$email=$phone=$type=$idnumber=null;

$nameT=$genderT=$emailT=$phoneT=$typeT=$idnumberT=false;

$message=$alert=null;
	
if (isset($_POST['reg_users'])) {
	
	$pfno=@$_POST['pfno'];
	$name=@$_POST['name'];
	$gender=@$_POST['gender'];
	$email=@$_POST['email'];
	$phone=@$_POST['phone'];
	$type=@$_POST['type'];
	$idnumber=@$_POST['idnumber'];


	if ($pfno && $name && $gender  && $phone && $type && ( ($email || !$email) && ($idnumber || !$idnumber)  ))  {
		
		


			if ($validator->userFullName($name) ) {
				$nameT=true;
			} else {
				$message.="<br/>Please enter a valid name";
			}

			

			
				if ($validator->phone($phone) ) {
					$phoneT=true;
				} else {
					$message.= "<br/>Please enter a valid phone number";
				}
					
				$password=null;
			

			if ($type !='OTHERS') {


				 $password=$AUTO_GEN->Authonticate_Passwords("4242",null,'g');




						if ($validator->mult_email($email)  ) {
						$emailT=true;
					} else {
						$message.= "<br/>Please enter a valid email address";
					}

					if ($validator->nationalID($idnumber) ) {
				$idnumberT=true;
			} else {
				$message.="<br/>Please enter a valid National ID Number";
			}


			


				
			}
			else
			{
				if ($email) {
					if ($validator->mult_email($email)  ) {
						$emailT=true;
					} else {
						$message.= "<br/>Please enter a valid email address";
					}
				} else {
					$emailT=true;
				}
				
						
				if ($idnumber) {
					if ($validator->nationalID($idnumber) ) {
				$idnumberT=true;
			} else {
				$message.="<br/>Please enter a valid National ID Number";
			}

			} else {
					$idnumberT=true;
				}



				
			

			}

			


			//send to server
			if ($nameT && $phoneT && $emailT && $idnumberT) {

				$insertSQL="INSERT into users ( pf_no , type, name ,gender , phone,email , password, idnumber ) values(
					".$Server->quote($pfno).",
					".$Server->quote($type).",
					".$Server->quote(strtoupper($name)).",
					".$Server->quote($gender).",
					".$Server->quote($phone).",
					
					".$Server->quote($email).",
					".$Server->quote($password).",
					".$Server->quote($idnumber)."

					)";

			if (@$_GET['action']=="update" && @$_GET['id']) 
			{
				$insertSQL="UPDATE  users SET 
					
					type=".$Server->quote($type).",
					name=".$Server->quote(strtoupper($name)).",
					gender=".$Server->quote($gender).",
					phone=".$Server->quote($phone).",
					
					email=".$Server->quote($email).",
					password=".$Server->quote($password).",
					idnumber".$Server->quote($idnumber)."

					WHERE pf_no=".$Server->quote($pfno);


					
			}
				$insertSQL=$Server->query($insertSQL) or die($Server->error());

				if ($insertSQL) {
					$Server-> commit();
					$alert="<br/>Details have been saved";

						if (@$_GET['action']=="update" && @$_GET['id']) 
			{
				$AUTO_GEN->reload($Site-> site_url);
			}
			else
			{
				$AUTO_GEN->reload();
			}

					

				} else {
					$Server->rollback();
					$alert="<br/>Details have not been saved <br/>
						Please check that there is no duplicate entry of either <strong> ID Number , Email or Phone </strong>
					";

				}
				
	
			}

			//end server;







	} else {
		$message.=  "<br/>Please provide all the details";
	}
	
	
}



 ?>




<div class="panel panel-primary">
	
<div class="panel-heading"> User Registartion</div>
	
	<div class="panel-body">

		<?php 

				echo $msg=$message?("<div class='alert alert-danger'> ".$message."</div>"):($alert?"<div class='alert alert-success'> $alert </div>":"");

			 ?>

	<form class="form-horizontal" method="post" action="">
		

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> PF Number </label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="pfno" class="form-control" value="<?php echo $pfno; ?>" readonly="readonly" >
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Full Name <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="name" class="form-control" value="<?php echo $name; ?>" >
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Gender <sup class="err fa fa-asterisk "></sup> </label>
				</div>
				<div class="col-sm-8">
				<label><input type="radio" name="gender"  value="Male" <?php echo ($gender=="Male")?"checked='checked'":null; ?>  > Male </label>
				<label><input type="radio" name="gender"  value="Female" <?php echo ($gender=="Female")?"checked='checked'":null; ?>   > Female </label>
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Select Type <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
					
				<select name="type" class="form-control	">
					<option value="<?php echo $type; ?>"><?php echo $type; ?></option>
					<option value="REGISTRAR">REGISTRAR</option>
					<option value="JUDGE">JUDGE</option>
					<option value="OTHERS">OTHERS</option>
				</select>

				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Phone <sup class="err fa fa-asterisk "></sup></label>
				</div>
				<div class="col-sm-8">
				<input type="text" name="phone" class="form-control" value="<?php echo $phone; ?>"  >
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> Email </label>
				</div>
				<div class="col-sm-8">

				<input type="text" name="email" class="form-control" value="<?php echo $email; ?>"  >
				</div>
			</div>


			<div class="form-group">
				<div class="col-sm-4">
					<label class="control-label"> ID Number </label>
				</div>
				<div class="col-sm-8">

				<input type="text" name="idnumber" class="form-control" value="<?php echo $idnumber; ?>"  >
				</div>
			</div>

		
				<div class="form-group">
				
				<div class="col-sm-12">
					<button class="btn btn-primary pull-right" name="reg_users"> Save</button>
				</div>
			</div>




	</form>
		
		
	</div>
</div>