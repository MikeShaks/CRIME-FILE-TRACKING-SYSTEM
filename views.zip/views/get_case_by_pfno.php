<?php 

include('../conf/conn.php');

$pfno=$_POST['pfno'];


  
if ($pfno) {
		
		  
		$selectPfno="SELECT * from case_reg_des  where pf_no=".$Server-> quote($pfno);
		$selectPfno=$Server-> select ($selectPfno);// or die($Server-> error());



		 if (count($selectPfno)>0) {
		 	?>

		 	<select name="case_number" class="form-control	case_number ">
					<option value="<?php echo @$case_number; ?>"><?php echo @$case_number; ?></option>
					
					<?php 

						
						foreach ($selectPfno as $key ) {
							?>
							<option value="<?php echo $key['case_no']." { ".$key['case_type']." > ".$key['case_sub_type']; ?>"> <?php echo $key['case_no']." { ".$key['case_type']." > ".$key['case_sub_type']; ?></option>

							<?php
						}

					 ?>
					
				</select>

					<?php
		 } else {
	?>

	<div class="alert alert-danger"> Case Not found for the user  <strong><?php echo strtoupper($pfno); ?> </strong>.</div>

	<?php
		 }
		 


} else {
	
	?>

	<div class="alert alert-danger"> County Not Selected</div>

	<?php
}


 ?>

<script type="text/javascript">
	

	
	$(".case_number").select2({
                    placeholder: "Select Case Number ",
                    allowClear: true
     }).change(function(){

            var case_number=$(".case_number").val();

          	$.post("views/get_posible_case_fees.php",{case_number: case_number }, function (data){
          		$(".case_posible_amount").html(data);
          	});
        });








</script>
