<?php 
	

  include('../conf/conn.php');


  $case_type=@$_POST['case_type'];
  $subType=@$_POST['subType'];


  if ($case_type && $subType) {
  	
  
  
  	$selectSQL="select type, fees  from case_fees where case_sub_type=".$Server->quote($subType) ." and  case_type=".$Server->quote($case_type) ;;// or die($Server->error());
		$selectSQL=$Server->select($selectSQL) or die($Server->error());


		$type=null;
		foreach ($selectSQL as $key ) {
			
			$type=strtolower($key['type']);
		    $fees=$key['fees'];
		}


  		$oldType=$type;

		 $type=($type=="fixed")?"readonly='readonly'":null;
		  $fees=($oldType=="fixed")?$fees:null;



 ?>

 <input type="text" name="fees" <?php echo $type; ?> class="form-control" placeholder="Enter Amount" value="<?php echo @$fees; ?>" >
	

	<?php 

  } else {
  	
 ?>

 		<div class="alert alert-danger"> Case Sub Type is not Selected.  </div>

 <?php
}
	 ?>			