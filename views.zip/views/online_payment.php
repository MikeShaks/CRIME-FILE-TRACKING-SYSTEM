
 <div class="panel panel-primary ">
 	<div class="panel-heading text-center">
 		
 		<h1>Paye for your Case  Online</h1>

 	</div>

 	<div class="panel-body case_payment_form">



<?php 




	if (@$_GET['pesapal_notification_type'] && @$_GET['pesapal_transaction_tracking_id'] && @$_GET['pesapal_merchant_reference']) {
		include_once 'pesapal-ipn-listener.php';

	} else {
		# code...
	}



	$message=$amount=$first_name=$last_name=$phone=null;
	$amountT=$first_nameT=$last_nameT=$phoneT=false;
	$amountErr=$first_nameErr=$last_nameErr=$emailErr=$phoneErr=false;

	$pfno=$case_number=null;

	$reference=$AUTO_GEN-> uniqueSmsReferenceNumber(8);




if (isset($_POST['make_payment'])) {


	$amount=@$_POST['amount'];
	$first_name=@$_POST['first_name'];
	$last_name=@$_POST['last_name'];
	$phone=@$_POST['phone'];

	$pfno=@$_POST['pfno'];
	$case_number=@$_POST['case_number'];
	

	if ($amount && $first_name && $last_name  && $phone && $pfno && $case_number) {
				



if ($validator->phone($phone)) {
   $phoneT=true;
  }
  else
  {
     $phoneErr="Please enter a valid Phone Number";
  }

  if ($validator->single_name($first_name)) {
   $first_nameT=true;
  }
  else
  {
     $first_nameErr="Please enter a Name";
  }
	
	if ($validator->single_name($last_name)) {
   $last_nameT=true;
  }
  else
  {
     $last_nameErr="Please enter a Name";
  }

  if ( $validator->numbers($amount)) {
   $amountT=true;
  }
  else
  {
     $amountErr="Please enter a Valid Amount";
  }
	

	if ($amountT && $first_nameT && $last_nameT && $phoneT && $pfno && $case_number) {
			

		include_once 'pesapal-iframe.php';

		exit;
	}
	

	} else {
		 $message="<div class=\"alert alert-danger text-center\"><span class=\"glyphicon glyphicon-warning-sign\"></span>  Please provide all the required details. </div>";
    
	}


	


}

 ?>



<form action="" class="table-responsive " method="post" >

<?php echo $message; ?>

	<table class="table ">
		<tr>
			<td>PF Number :</td>
			<td><select name="pfno" class="form-control	pfno " >
					<option value="<?php echo $pfno; ?>"><?php echo $pfno; ?></option>
					
					<?php 

						$selectPfno="SELECT * from users";
						$selectPfno=$Server->query($selectPfno);

						foreach ($selectPfno as $key ) {
							?>
							<option value="<?php echo $key['pf_no']; ?>"> <?php echo $key['name']."   [ ".$key['pf_no']." ]"; ?></option>

							<?php
						}

					 ?>
					
				</select>

				<br/>
				<div class="pfno_display"></div>
			</td>



		</tr>

		<tr class="get_file_number">

			<td>Case Number :</td>
			<td>

				<div  class="case_number_payment"> 
				Please select a PF Number 

			</div>

			</td>



		</tr>


		<tr>
			<td>Amount:</td>
			<td>

				<div class="col-sm-6">
					<input type="text" class="form-control" name="amount" value="<?php echo $amount; ?>" />
			(in Kshs)

			<p class="err"><?php echo $amountErr; ?></p>
				</div>
				<div class="col-sm-6 case_posible_amount">
					
				</div>

			
			</td>
		</tr>
		
		
		
		<tr>
			<td>Description:</td>
			<td><input type="text" name="description" class="form-control" readonly="readonly" value="Website Payment" />

			</td>
		</tr>
		<tr>
			<td>Reference:</td>
			<td><input type="text" class="form-control" readonly="readonly" name="reference" value="<?php echo $reference; ?>" />
			
			</td>
		</tr>
		<tr>
			<td>Shopper's First Name:</td>
			<td><input type="text" class="form-control" name="first_name" value="<?php echo $first_name; ?>" />
			<p class="err"><?php echo $first_nameErr; ?></p></td>
		</tr>
		<tr>
			<td>Shopper's Last Name:</td>
			<td><input type="text" class="form-control" name="last_name" value="<?php echo $last_name; ?>" />
			<p class="err"><?php echo $last_nameErr; ?></p>
			</td>
		</tr>
		<tr>
			<td>Shopper's Phone Number:</td>
			<td><input type="text" class="form-control" name="phone" value="<?php echo $phone; ?>" />
			<p class="err"><?php echo $phoneErr; ?></p>
			</td>
		</tr>
		
		<tr>
			
			<td colspan="2">

			<input type="hidden" name="type" class="form-control" value="MERCHANT" readonly="readonly" />


				<input type="submit" name="make_payment" class="btn btn-primary pull-right" value="Make Payment" /></td>
		</tr>
	</table>
</form>

	</div>
 </div>


 